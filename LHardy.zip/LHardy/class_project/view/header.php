<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <title>Course Enrollment and Management</title>
    <link rel="stylesheet" type="text/css"
          href="/LHardy/class_project/main.css">
</head>


<!-- the body section -->
<body>
<header>
    <h1>Course Enrollment and Management</h1>
    <p>Registration and Information for Students</p>
    <nav>
        <ul>
            <li><a href="/LHardy/class_project/index.php">Home</a></li>
        </ul>
    </nav>
</header>
