
<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> Course Enrollment Management
    </p>
</footer>
</body>
</html>