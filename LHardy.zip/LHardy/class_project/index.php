 <?php include 'view/header.php'; ?>

<main>
    
    
    <nav>
        
    <h2>Register</h2>
    <ul>
        <li><a href="student_register">Student Registration</a></li>
    </ul>

    <h2>Login</h2>    
    <ul>
        <li><a href="student_login">Student Login</a></li>
    </ul>

    <h2>Information</h2>
    <ul>
        <li><a href="course_information">Course Information</a></li>
    </ul>
    
    <ul>
        <li><a href="personal_information">Personal Information</a></li>
    </ul>
    
    </nav>
    
<?php include 'view/footer.php'; ?>