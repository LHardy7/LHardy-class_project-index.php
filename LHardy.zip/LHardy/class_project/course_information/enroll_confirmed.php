<?php include '../view/header.php'; ?>
<main>
    <h1>Course Enrolled</h1>
    
    <p>You have successfully enrolled.</p>
    
</main>
<?php include '../view/footer.php'; ?>